﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bird : MonoBehaviour {
    //외부접근이 가능한 실수형 jumpPower는 5를 대입
    //외부접근이 가능한 게임 오브젝트 imageBird
    //외부접근이 가능한 Vector3 lookDireton
    //외부접근이 가능한 고정형 Brid bird생성
    public float jumpPower = 5f;
    public GameObject imageBird;
    public Vector3 lookDireton;
    public static Bird bird;

    Rigidbody rb; //게임의 오브젝트가 물리제어가 가능한 컴포넌트

    //Awake함수는 스크립트 객체의 라이프 사이클중에 단 한번만 호출되며\
    //시작시 게임 객체를 초기화 가능하다
    void Awake()
    {
        bird = this;
        rb = GetComponent<Rigidbody>();
    }
    
	// Update is called once per frame
	void Update () {
        //게임매니저의 end상태가 false일때만 뛸수있게
        if (GameManagement.manager.end == false)
        {
            //만약에 마우스 왼쪽 버튼을 누르고 그리고 나의 Y위치가 5보다 작을 때
            //뭔가 동작을 할것임
            if (Input.GetMouseButtonDown(0) && this.transform.position.y < 5)
            {
                rb.velocity = new Vector3(0f, 0f, 0f); //물리 제어 초기화
                                                       //Rigidbody에 AddForce는 힘을 실어주다와 같음
                rb.AddForce(0, jumpPower, 0, ForceMode.VelocityChange);

                //ForceMode.Acceleration : 물체의 질량의 영향을 받지 않고 연속적 힘을 가할 때
                //ForceMode.Force : 물체 질량의 영향을 받고 연속적 힘을 가할 때 
                //ForceMode.Impulse : 질량에 의하여 순간적으로 값의 변화가 있음
                //ForceMode.VelocityChange  : 질량에 영향을 받지 않고 순간적으로 값을 변화함
                GetComponent<AudioSource>().Play();

            }
            //새가 점프했을때 새가 바라보는 방향을 변화
            //Y축으로 회전
            if(GameManagement.manager.ready == false)
            {
                lookDireton.z = rb.velocity.y * 10f + 20f;
            }
        }
        Quaternion R = Quaternion.Euler(lookDireton);
        imageBird.transform.rotation = Quaternion.RotateTowards(imageBird.transform.rotation, R, 5f);

    }
    
    //Collider의 충돌에 동작하는 함수
    void OnTriggerEnter(Collider target)
    {
        //만약에 타겟의 태그가  == pillar와 같으면 
        //rb.velocity = new Vector3의 y축을 -3으로
        //lookDri~~의 z값을 -90으로 갱신(초기화)
        
      
        if(target.tag == "Pillar")
        {
            rb.velocity = new Vector3(0,-3f,0);
            lookDireton = new Vector3(0, 0, -90f);
            GameManagement.manager.충돌();
            //GameManagement.manager.GameOver();

        }//그것이 아니고 타겟의 태그가 Goal이라면 GetScore를 통해 점수 +
        else if(target.tag == "Goal")
        {
            GameManagement.manager.GetScore();
        }
    }
}
 