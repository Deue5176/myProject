﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PillarMove : MonoBehaviour {
    public float pillarSpeed;

	// Update is called once per frame
	void Update () {
        //위치값의 변화 왼쪽으로 
        transform.Translate(Vector3.left * pillarSpeed * Time.deltaTime);
        //(원통 == 나)의 x좌표가 -6이 되면
        //만약에 나의 위치 중에 x좌표가 -6보다 작으면
        if(transform.position.x < -6)
        {
            // 원통 자기 자신객체를 삭제하시오.
            Destroy(this.gameObject);
        }
        
    }
    void OnEnable()
    {   
        //원통의 시작점x를 6에서
        //높낮이를 최소 -1에서 최대 1.5사이에 랜덤하게 나오도록 하시오
     
        transform.position = new Vector3(6f, Random.Range(-1f,1.5f), 0f);
    }
}
