﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scroll_Back : MonoBehaviour {

    public float scrollSpeed;
    float targetOffset;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //배경이 계속 뒤로 지나가게 만들어 주는 기능
        targetOffset += Time.deltaTime * scrollSpeed;
        GetComponent<Renderer>().material.mainTextureOffset = new Vector2(targetOffset, 0);

	}
}
