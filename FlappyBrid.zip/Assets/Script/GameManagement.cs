﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//pillar 의 2개 묶음 또는 3개 묶음의 프리팹을 생성하시오
//pillar의 1개 묶음은 50%확률로, 2개 묶음은 30% 확률로 3개 묶음은 20% 확률로 나타날 수 있도록 하시오.

public class GameManagement : MonoBehaviour {
    //외부접근이 가능한 실수형 변수 waiting 에는 1.5 값을대입
    public float waitingTime = 1.5f;
    //외부접근이 가능하고 고정형 GameManagement manager 생성
    public static GameManagement manager;
    //외부접근이 가능한 bool형 ready에는 true값을 대입
    public bool ready = true;
    public bool end = false;

    public int 체력 = 5;
    public TextMesh 체력Text;
    
    //외부접근이 가능한 게임오브젝트 pillar생성
    public GameObject pillar;
    public GameObject pillar2;
    public GameObject pillar3;

    //점수저장용 변수
    public int score;
    
    //텍스트를 표기 표기
    public TextMesh scoreText;

    //최종 결과 보드에 나타내기 위한 변수
    public int BestScore;
    public TextMesh finalText;
    public TextMesh BestText;

    //소리를 담기 위한 변수
    public AudioClip deadSound;
    public AudioClip goalSound;

    //인트로 이미지
    public GameObject getReady;
    public GameObject tabReady;

    public GameObject gameOverlmage;
    //안보여지다가 보여지는거?


    public GameObject newImage;

	void Start () {
        manager = this;
        //setA는 활성 상태를 설정
        gameOverlmage.SetActive(false);
       // PlayerPrefs.SetInt("BestScore", 0);
    }
	
	// Update is called once per frame
	void Update () {
      
		//마우스 왼쪽 버튼(0)을 누르고 그리고 ready가 ture일 때, 
        //ready를 false하도록 한다.
        if(Input.GetMouseButtonDown(0) && ready == true)
        {
            ready = false;
            //반복함수를 이용
            //**(시험) InvokeRepeating("실행하는 함수", 최초 실행까지의 시간, 반복 실행의 간격시간)
            InvokeRepeating("MakePillar", 1f, waitingTime);
            //게임플레이 상태로 변경
            //중력을 인계
            Bird.bird.gameObject.GetComponent<Rigidbody>().useGravity = true;

            getReady.transform.position = new Vector3(0, -10, 0);
            tabReady.transform.position = new Vector3(0, -10, 0);

        }
    }
    void MakePillar()
    {
        //random.range 를 통해 0~ 10 사이의 랜덤한 숫자를 생성 
        int randomvalue = Random.Range(0, 10);//randomvalue 의 값이 4 이하일 경우 1개의 pillar 를 생성
        if (randomvalue <= 4)
        {   
            Instantiate(pillar);
        }
        else if(randomvalue > 4 && randomvalue <= 7)//randomvalue 의 값이 위의 경우 2개의 pillar 를 생성
        {
            
            Instantiate(pillar2); 
        }
        else //randomvalue 의 값이 두 조건을 만족하지 않는 경우  3개의 pillar 를 생성
        {
            Instantiate(pillar3);
        } 
        //객체를 지속적으로 생성하는 함수
        //Instantiate(pillar);
    }
    //새가 기둥과 충돌시 실행되는 함수
    public void GameOver()
    {
        //게임이 끝나고 한번더 발동되는 경우를 막음
        if (end == true)
        {
            return;
        }
        //end의 변화
        end = true;
        CancelInvoke("MakePillar");
        AudioSource.PlayClipAtPoint(deadSound, transform.position);
        gameOverlmage.SetActive(true);
        finalText.text = score.ToString();

        //PlayerPrefs.set int, string, float ("key")
        //데이터를 단말에 저장할때 사용함(localStorage)
        if(score > PlayerPrefs.GetInt("BestScore")){
            newImage.SetActive(true); //newimage를 보이게 해줌
            BestText.text = score.ToString(); //bestText의 택스트 정보를 스코어로 변경
            PlayerPrefs.SetInt("BestScore", score); //갱신된 최고 점수를 저장
        }
        else
        {
            BestText.text = PlayerPrefs.GetInt("BestScore").ToString(); //저장된 최고 점수를 불러온다.
            newImage.SetActive(false);
        }
        
    }
    //점수 상승 함수, 점수를 더해주고 점수판의 정보를 갱신한다.
    public void GetScore()
    {
        score += 1;
        scoreText.text = score.ToString();
        finalText.text = score.ToString();

        AudioSource.PlayClipAtPoint(goalSound, transform.position); //아이템 획득 또는 물체가 충돌했을때 사운드를 출력하기 위해 쓸 수 있는 스크립트
    }
    public void 충돌()
    {
     
        if (체력 <= 0)
        {
            GameOver();
        }else
        {
            체력--;
            체력Text.text = "life : " + 체력.ToString();
            //카메라 흔들리는 효과
            camerafollow.Camerafollow.ShakeCamera(0.1f, 0.5f);
        }
    
    }
}
