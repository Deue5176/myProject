﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; //라이브러리와 같음

public class Resetscenes : MonoBehaviour {

    private void OnMouseDown()
    {
        // 게임을 다시 불러온다.
        SceneManager.LoadScene(0);
    }
}
