﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camerafollow : MonoBehaviour
{

    public static camerafollow Camerafollow;

    //화면(카메라가 흔들리는 시간
    public float shakeTimer = 0;


    //흔들리는 범위
    public float shakeAmount;

    public Vector2 velocity;
    public float smoothTimeX;
    public float smoothTimeY;
    public GameObject holdPlace; //  움직이지 않는 객체


    // Start is called before the first frame update
    void Start()
    {
        Camerafollow = this;
    }

    // Update is called once per frame
    void Update()
    {
        if(shakeTimer >= 0)
        {
            //카메라는 2D 형태로 바라보고 있음
            //랜덤한 원형을 그리는 값을 생성(Amount)값을 곱하여 
            Vector2 shackPos = Random.insideUnitCircle * shakeAmount;

            //Vector3 를 쓰는 이유 : transform.position  이 x,y,z 축을 가지기 때문 
            transform.position = new Vector3(transform.position.x + shackPos.x, transform.position.y + shackPos.y, transform.position.z);
            //그와 동시에 시간을 감소하여 shakeTimer가 0이 되면 흔드는 효과를 멈
            shakeTimer -= Time.deltaTime;
        }
        
    }

    public void ShakeCamera(float shakepwr, float shakeDur)
    {
        shakeAmount = shakepwr;
        shakeTimer = shakeDur;
    }

    private void FixedUpdate()
    {
        //카메라를 매 프레임 마다 원위치로 이동 시키기 위한 설정
        //x위치, y위치를 고정할 수 있는 위치값을 가지고
        // Mathf.SmoothDamp 를 사용시 좀더 부드럽게 움직인다.

        float PosX = Mathf.SmoothDamp(transform.position.x, holdPlace.transform.position.x, ref velocity.x, smoothTimeX);
        float PosY = Mathf.SmoothDamp(transform.position.y, holdPlace.transform.position.y, ref velocity.y, smoothTimeY);
        //update 이후 다시 돌아 오도록 수정
        transform.position = new Vector3(PosX, PosY, transform.position.z);
    }
}
