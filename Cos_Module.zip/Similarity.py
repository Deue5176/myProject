import pymysql
import pandas as pd

class Similarity():
    def Top(self, ID):
        # Table_Name = 유사도 테이블 이름 ,ID 유사도 리스트를 뽑을 영상의 ID , Limit 리스트의 갯수
        qurry_tabel = str(Similarity.Video_categori(ID))
        qurry_id = str(ID)
        print(qurry_tabel)
        qurry_id = qurry_id.replace("'", "`")
        conn = pymysql.connect(host='113.198.236.244', user='dblab1', password='dblab1', db='reco', charset='utf8')
        curs = conn.cursor(pymysql.cursors.DictCursor)
        sql = "SELECT `video_id` FROM " + qurry_tabel + " WHERE `" + qurry_id + "` <=0.99 order BY `" + qurry_id + "` desc LIMIT 20;"

        curs.execute(sql)

        Top_List = pd.DataFrame(curs.fetchall())
        Top_List = list(Top_List.iloc[:, 0])
        conn.close()
        print(Top_List)
        return Top_List

    def Video_categori(id):

        qurry_id = str(id)
        conn = pymysql.connect(host='113.198.236.244', user='dblab1', password='dblab1', db='reco', charset='utf8')
        curs = conn.cursor(pymysql.cursors.DictCursor)
        sql = "SELECT `Video_categori` FROM reco.video WHERE `video_id` = '" + qurry_id + "';"

        curs.execute(sql)
        conn.close

        categori_id = pd.DataFrame(curs.fetchall())
        categori_id = list(categori_id.iloc[:, 0])

        s = str(categori_id[0])
        a = 0

        if (s == '문학'):
            a = '문학_유사도'
        elif (s == '수학'):
            a = '수학_유사도'
        elif (s == '영어'):
            a = '영어_유사도'
        elif (s == '생물'):
            a = '생물_유사도'
        elif (s == '화학'):
            a = '화학_유사도'
        elif (s == '물리'):
            a = '물리_유사도'
        elif (s == '지구과학'):
            a = '지구과학_유사도'
        elif (s == '음악'):
            a = '음악_유사도'
        elif (s == '미술'):
            a = '미술_유사도'
        elif (s == '체육'):
            a = '체육_유사도'
        elif (s == '한국사'):
            a = '한국사_유사도'
        elif (s == '법과정치'):
            a = '법과정치_유사도'
        elif (s == '경제'):
            a = '경제_유사도'
        elif (s == '생활윤리'):
            a = '생활윤리_유사도'
        elif (s == '한국지리'):
            a = '한국지리_유사도'
        elif (s == '세계지리'):
            a = '세계지리_유사도'
        elif (s == '세계사'):
            a = '세계사_유사도'
        elif (s == '동아시아사'):
            a = '동아시아사_유사도'
        elif (s == 'IT'):
            a = 'it_유사도'
        elif (s == '제2외국어'):
            a = '제2외국어_유사도'
        return str(a)
