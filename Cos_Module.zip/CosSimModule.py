from pandas import DataFrame
from sklearn.metrics.pairwise import cosine_similarity
import pymysql
from sqlalchemy import create_engine
import pandas as pd


def insertCosineDB(DtmTable , CosinTable):

    df1 = loadDtm(str(DtmTable))
    id_list = list(df1.iloc[0:0])
    id_list = str(id_list[0])
    cos_table = str(CosinTable)

    DTM_ID = DataFrame(df1.iloc[:,0])

    dtm_id = list(df1.iloc[:, 0])
    dtm_id = list(map(str, dtm_id))

    del df1[id_list]

    CosinDf = DataFrame(cosine_similarity(df1,df1),columns=dtm_id)
    resultDf = pd.concat([DTM_ID,CosinDf] ,axis=1)

    # 'fail = 아무동작 안함 'replace' 기존 테이블 삭제하고 새로 테이블을 생성 'append' 테이블이 존재하면 데이터만 추가
    cnx = create_engine('mysql+pymysql://dblab7:dblab7@113.198.236.244:3306/reco', echo=False)
    resultDf.to_sql(name=cos_table, con=cnx, if_exists = 'replace', index=False, index_label='ID')
    print(CosinTable,'업데이트 완료')


def loadDtm(TableName):
    conn = pymysql.connect(host='113.198.236.244', user='dblab7', password='dblab7', db='reco', charset='utf8')
    #conn = pymysql.connect(host='localhost', user='root', password='0000', db='mydb', charset='utf8')
    curs = conn.cursor(pymysql.cursors.DictCursor)
    sql = "SELECT * FROM reco."+str(TableName)
    curs.execute(sql)
    DTM_DF = DataFrame(curs.fetchall())
    conn.close()
    return DTM_DF



def Top_List(ID):
    #ID 유사도 리스트를 뽑을 영상의 ID , Limit 리스트의 갯수

    qurry_tabel = str(Video_categori(ID))
    qurry_id = str(ID)

    qurry_id = qurry_id.replace("'","`")
    conn = pymysql.connect(host='113.198.236.244', user='dblab7', password='dblab7', db='reco', charset='utf8')
    curs = conn.cursor(pymysql.cursors.DictCursor)
    sql = "SELECT `video_id` FROM "+qurry_tabel+" WHERE `"+ qurry_id +"` <=0.99 order BY `"+ qurry_id +"` desc LIMIT 20;"

    curs.execute(sql)

    Top_List = DataFrame(curs.fetchall())
    Top_List = list(Top_List.iloc[:,0])
    conn.close()

    return Top_List

def Delete_CosDB (ID):
    # ID = 삭제할 비디오의 ID

    qurry_id = str(ID)
    cos_table = str(Video_categori(qurry_id))
    Delete_DB(cos_table, qurry_id)


    testlist = []
    testlist = Select_Clip(qurry_id)
    cos_table = str(Clip_categori(qurry_id))
    print(cos_table)

    for i in testlist:
        print(i)
        Delete_DB(cos_table, i)



def Delete_DB (cosin_talbe , ID):
    #cosin_table = 삭제할 유사도 테이블 , ID =  삭제할 영상의 ID

    df1 = loadDtm(str(cosin_talbe))
    id_list = list(df1.iloc[0:0])
    id_list = str(id_list[0])


    qurry_tabel = str(cosin_talbe)
    conn = pymysql.connect(host='113.198.236.244', user='dblab7', password='dblab7', db='reco', charset='utf8')
    curs = conn.cursor()

    sql = "DELETE FROM `"+str(qurry_tabel)+"` WHERE "+id_list+" = "+str(ID)+";"
    print(sql)
    curs.execute(sql)
    conn.commit()

    sql2 ="ALTER TABLE `"+str(qurry_tabel)+"` DROP COLUMN `"+str(ID)+"`; "
    print(sql2)
    curs.execute(sql2)
    conn.commit()
    conn.close()

def Select_Clip(id):
    qurry_id = str(id)
    conn = pymysql.connect(host='113.198.236.244', user='dblab7', password='dblab7', db='reco', charset='utf8')
    curs = conn.cursor(pymysql.cursors.DictCursor)
    sql = "SELECT `clip_id` FROM clip WHERE `video_id` = "+ qurry_id+";"
    curs.execute(sql)
    DTM_DF = DataFrame(curs.fetchall())
    Clip_list = list(DTM_DF.iloc[:, 0])
    conn.close()
    return Clip_list

def Clip_categori(id):

    qurry_id = str(id)
    conn = pymysql.connect(host='113.198.236.244', user='dblab7', password='dblab7', db='reco', charset='utf8')
    curs = conn.cursor(pymysql.cursors.DictCursor)
    sql = "SELECT `Video_categori` FROM reco.video WHERE `video_id` = '" + qurry_id + "';"
    curs.execute(sql)
    conn.close

    categori_id = DataFrame(curs.fetchall())
    categori_id = list(categori_id.iloc[:, 0])

    s = str(categori_id[0])
    a = 0

    if (s == '문학'):
        a = '문학_클립_유사도'
    elif (s == '수학'):
        a = '수학_클립_유사도'
    elif (s == '영어'):
        a = '영어_클립_유사도'
    elif (s == '생물'):
        a = '생물_클립_유사도'
    elif (s == '화학'):
        a = '화학_클립_유사도'
    elif (s == '물리'):
        a = '물리_클립_유사도'
    elif (s == '지구과학'):
        a = '지구과학_클립_유사도'
    elif (s == '음악'):
        a = '음악_클립_유사도'
    elif (s == '미술'):
        a = '미술_클립_유사도'
    elif (s == '체육'):
        a = '체육_클립_유사도'
    elif (s == '한국사'):
        a = '한국사_클립_유사도'
    elif (s == '법과정치'):
        a = '법과정치_클립_유사도'
    elif (s == '경제'):
        a = '경제_클립_유사도'
    elif (s == '생활윤리'):
        a = '생활윤리_클립_유사도'
    elif (s == '한국지리'):
        a = '한국지리_클립_유사도'
    elif (s == '세계지리'):
        a = '세계지리_클립_유사도'
    elif (s == '세계사'):
        a = '세계사_클립_유사도'
    elif (s == '동아시아사'):
        a = '동아시아사_클립_유사도'
    elif (s == 'IT'):
        a = 'it_클립_유사도'
    elif (s == '제2외국어'):
        a = '제2외국어_클립_유사도'
    return str(a)

def Video_categori(id):

    qurry_id = str(id)
    conn = pymysql.connect(host='113.198.236.244', user='dblab7', password='dblab7', db='reco', charset='utf8')
    curs = conn.cursor(pymysql.cursors.DictCursor)
    sql = "SELECT `Video_categori` FROM reco.video WHERE `video_id` = '" + qurry_id + "';"

    curs.execute(sql)
    conn.close

    categori_id = DataFrame(curs.fetchall())
    categori_id = list(categori_id.iloc[:, 0])

    s = str(categori_id[0])
    a = 0

    if (s == '문학'):
        a = '문학_유사도'
    elif (s == '수학'):
        a = '수학_유사도'
    elif (s == '영어'):
        a = '영어_유사도'
    elif (s == '생물'):
        a = '생물_유사도'
    elif (s == '화학'):
        a = '화학_유사도'
    elif (s == '물리'):
        a = '물리_유사도'
    elif (s == '지구과학'):
        a = '지구과학_유사도'
    elif (s == '음악'):
        a = '음악_유사도'
    elif (s == '미술'):
        a = '미술_유사도'
    elif (s == '체육'):
        a = '체육_유사도'
    elif (s == '한국사'):
        a = '한국사_유사도'
    elif (s == '법과정치'):
        a = '법과정치_유사도'
    elif (s == '경제'):
        a = '경제_유사도'
    elif (s == '생활윤리'):
        a = '생활윤리_유사도'
    elif (s == '한국지리'):
        a = '한국지리_유사도'
    elif (s == '세계지리'):
        a = '세계지리_유사도'
    elif (s == '세계사'):
        a = '세계사_유사도'
    elif (s == '동아시아사'):
        a = '동아시아사_유사도'
    elif (s == 'IT'):
        a = 'it_유사도'
    elif (s == '제2외국어'):
        a = '제2외국어_유사도'
    return str(a)


def Top(Table_Name, ID, Limit):
    # Table_Name = 유사도 테이블 이름 ,ID 유사도 리스트를 뽑을 영상의 ID , Limit 리스트의 갯수

    qurry_id = str(ID)
    qurry_Limit = str(Limit)
    qurry_tabel = str(Table_Name)

    qurry_id = qurry_id.replace("'", "`")
    conn = pymysql.connect(host='113.198.236.244', user='dblab7', password='dblab7', db='reco', charset='utf8')
    curs = conn.cursor(pymysql.cursors.DictCursor)
    sql = "SELECT `video_id` FROM " + qurry_tabel + " WHERE `" + qurry_id + "` <=0.99 order BY `" + qurry_id + "` desc LIMIT " + qurry_Limit + ";"

    curs.execute(sql)
    Top_List = DataFrame(curs.fetchall())
    Top_List = list(Top_List.iloc[:, 0])
    conn.close()
    return Top_List

def Delete_log(ID):
    conn = pymysql.connect(host='113.198.236.244', user='dblab7', password='dblab7', db='reco', charset='utf8')
    curs = conn.cursor()

    sql = "DELETE FROM `rating` WHERE video_id = " + str(ID) + ";"
    print(sql)
    curs.execute(sql)
    conn.commit()
    sql = "DELETE FROM `log` WHERE video_id = " + str(ID) + ";"
    print(sql)
    curs.execute(sql)
    conn.commit()



# Top
#  a = str(Video_Type)
#     #
    # qurry_table = ""
    # if a == 1:
    #    qurry_tabel = str(Vedeo_Categori2(ID))
    # else:
    #    qurry_tabel = str(Clip_Categori2(ID))