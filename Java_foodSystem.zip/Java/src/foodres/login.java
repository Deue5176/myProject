package foodres;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class login extends JFrame {

	private JPanel contentPane;
	private JTextField pw;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	
	
	
	
	

	/**
	 * Create the frame.
	 */
	public login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 352, 257);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		
		JLabel lblNewLabel = new JLabel("New label");
		panel.add(lblNewLabel);
		
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("password :");
		lblNewLabel_3.setBounds(65, 109, 70, 15);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("\uB85C\uADF8\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			
				String psw = pw.getText();		
					// JtextFiled�� �ִ� ���� psw ������ �����Ѵ�.
				if(psw.equals("")){
					// ���� psw�� ���� ""�� ��� ���â�� ����.
					JOptionPane.showMessageDialog(null, "��ĭ�Դϴ�.");}
				else{
					if(psw.equals("0000")){
						// ���� psw�� ����  0000 �� ��� �α��� ����â�� ����.
					JOptionPane.showMessageDialog(null, "�α��� ����");
					Main.showadmin();
					dispose();}
					else{JOptionPane.showMessageDialog(null, "�߸��� ��й�ȣ �Դϴ�.");
					// ���� psw�� ���� Ʋ�� ��� �α��� ���â���� ����.
						
					}
				}	
			}
		});
		btnNewButton.setBounds(54, 158, 97, 23);
		contentPane.add(btnNewButton);
		
		pw = new JTextField();
		pw.setBounds(134, 106, 116, 21);
		contentPane.add(pw);
		pw.setColumns(10);
		
		JButton button = new JButton("\uB3CC\uC544\uAC00\uAE30");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.showhome();
				dispose();
			}
		});
		button.setBounds(183, 158, 97, 23);
		contentPane.add(button);
		
		JLabel lblNewLabel_2 = new JLabel("\uAD00\uB9AC\uC790 \uB85C\uADF8\uC778");
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 20));
		lblNewLabel_2.setBounds(65, 43, 134, 33);
		contentPane.add(lblNewLabel_2);
	}
}
