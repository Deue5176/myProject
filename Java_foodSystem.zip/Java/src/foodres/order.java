package foodres;


import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.PreparedStatement;

import foodres.Main;
import net.proteanit.sql.DbUtils;
import foodres.dbc;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;





import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import foodres.Main;
import foodres.dbc;
import foodres.DBConnectionMgr;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTabbedPane;

 


@SuppressWarnings({ "unused", "serial" })
public class order extends JFrame {

	private JPanel contentPane;
	private JTextField tf_count;
	
	private JTable table;
	
    static String tn = "food1";
    private JTable table_1;
    static int num = 1;
    static int tab = 0;
    private JTextField tf_food;
    private JTextField tf_price;
    private JTextField tf_num;
  

		

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		order frame = new order();
		frame.setVisible(true);
	}

	/**
	 * Create the frame.
	 */
	public order() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 870, 505);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
	
		scrollPane.setBounds(67, 35, 452, 149);
		contentPane.add(scrollPane);

		
		table = new JTable();
		try{
	         Connection con = (Connection) dbc.dbcon();
	         String sql = "select*from food1";
	         Statement st= (Statement) con.createStatement();
	         ResultSet Rs = st.executeQuery(sql);
	         table.setModel(DbUtils.resultSetToTableModel(Rs));
	         tf_count.setText("");
	         tf_food.setText("");
	      }catch(Exception w){
	         w.printStackTrace();
	         
	      } 
		
		
		scrollPane.setViewportView(table);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			
				int row = table.getSelectedRow();
				if(row>=0){
				

				String name = table.getValueAt(table.getSelectedRow(), 1).toString();
				String date = table.getValueAt(table.getSelectedRow(), 2).toString();
				
				tf_food.setText(name);
				tf_price.setText(date);
				tf_count.setText("1");
	
				
				}
				else
				{
					return;
				
			
			
			
		}}
		});
		

		
		JButton btnNewButton = new JButton("\uAE40\uBC25");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tn =null;
				tn = "food1";
	
				
				try{
			         Connection con = (Connection) dbc.dbcon();
			         String sql = "select*from food1";
			         Statement st= (Statement) con.createStatement();
			         ResultSet Rs = st.executeQuery(sql);
			         table.setModel(DbUtils.resultSetToTableModel(Rs));
			         tf_count.setText("");
			         tf_food.setText("");
			         tf_price.setText("");
			      }catch(Exception w){
			         w.printStackTrace();
			         
			      } 			
			}
		});
		btnNewButton.setBounds(174, 2, 97, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("\uC218\uB7C9:");
		lblNewLabel_1.setBounds(631, 112, 75, 15);
		contentPane.add(lblNewLabel_1);
		
		tf_count = new JTextField();
		tf_count.setColumns(10);
		tf_count.setBounds(712, 109, 116, 21);
		contentPane.add(tf_count);
		
		JButton button = new JButton("\uCD94 \uAC00");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
					

					
					int a = Integer.parseInt(tf_price.getText())*Integer.parseInt(tf_count.getText());  				    
				    tf_price.setText(Integer.toString(a));
				    
					Connection con = (Connection) dbc.dbcon();
					
					PreparedStatement pstmtAdd = (PreparedStatement) con.prepareStatement("insert into older values(?,?,?,?,?)");

					

					
					pstmtAdd.setLong(1, num);
					pstmtAdd.setLong(2, tab);
					pstmtAdd.setString(3, tf_food.getText());
					pstmtAdd.setString(4, tf_count.getText());
					pstmtAdd.setString(5, tf_price.getText());					
					++num;
					
					pstmtAdd.executeUpdate();					
					String sql = "select*from older where orderlist =\'"+tab+"\'";
					Statement st= (Statement) con.createStatement();
					ResultSet Rs = st.executeQuery(sql);
					table_1.setModel(DbUtils.resultSetToTableModel(Rs));
					
					tf_count.setText("");
					tf_food.setText("");
					tf_price.setText("");
					
					
					
				}catch(Exception w){
					w.printStackTrace();
					
				}
				
				
				
				
				
			}
		});
		
		
		
		button.setBounds(731, 227, 97, 23);
		contentPane.add(button);
		
		JButton button_1 = new JButton("\uC0AD \uC81C");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
							
					String sql = "delete from older where num= \'"+tf_num.getText()+"\'";
					Connection con = (Connection) dbc.dbcon();
					Statement s = (Statement) con.prepareStatement(sql);
				 
					
					tf_food.setText("");
					tf_count.setText("");
					tf_price.setText("");
					s.execute(sql);
					String sql1 = "select*from older where orderlist =\'"+tab+"\'";
					Statement st= (Statement) con.createStatement();
					ResultSet Rs = st.executeQuery(sql1);
					table_1.setModel(DbUtils.resultSetToTableModel(Rs));
					JOptionPane.showMessageDialog(null, "���� ���� ����");
					
				}catch(Exception ex){
					ex.printStackTrace();
					JOptionPane.showMessageDialog(null, "���� ���� ����");
				}
			
				
			}
		});
		button_1.setBounds(731, 260, 97, 23);
		contentPane.add(button_1);
		
		JButton btnNewButton_2 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.showhome();
				dispose();
			}
		});
		btnNewButton_2.setBounds(731, 356, 97, 23);
		contentPane.add(btnNewButton_2);
		
		JButton button_2 = new JButton("\uB77C \uBA74");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tn =null;
				tn = "food2";
				
				try{
			         Connection con = (Connection) dbc.dbcon();
			         String sql = "select*from food2";
			         Statement st= (Statement) con.createStatement();
			         ResultSet Rs = st.executeQuery(sql);
			         table.setModel(DbUtils.resultSetToTableModel(Rs));
	
			         tf_count.setText("");
			         tf_food.setText("");
			         tf_price.setText("");
			      }catch(Exception w){
			         w.printStackTrace();
			         
			      } 
														
			}
		});
		button_2.setBounds(283, 2, 97, 23);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("\uB5A1\uBCF6\uC774");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tn =null;
				tn = "food3";
			
				try{
			         Connection con = (Connection) dbc.dbcon();
			         String sql = "select*from food3";
			         Statement st= (Statement) con.createStatement();
			         ResultSet Rs = st.executeQuery(sql);
			         table.setModel(DbUtils.resultSetToTableModel(Rs));

			         tf_count.setText("");
			         tf_food.setText("");
			         tf_price.setText("");
			         
			      }catch(Exception w){
			         w.printStackTrace();
			         
			      } 
				
			}
		});
		button_3.setBounds(392, 2, 97, 23);
		contentPane.add(button_3);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(67, 230, 452, 149);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row = table_1.getSelectedRow();
				if(row>=0){
				
				String name = table_1.getValueAt(table_1.getSelectedRow(), 0).toString();				
				
				tf_num.setText(name);	
				
				}
				else
				{
					return;
				
						
			
		}
			}
		});
		try{
	         Connection con = (Connection) dbc.dbcon();
	         String sql = "select*from older where orderlist =\'"+tab+"\'";
	         Statement st= (Statement) con.createStatement();
	         ResultSet Rs = st.executeQuery(sql);
	         table_1.setModel(DbUtils.resultSetToTableModel(Rs));
	         tf_count.setText("");
	      }catch(Exception w){
	         w.printStackTrace();
	         
	      } 
		
		scrollPane_1.setViewportView(table_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uBA54\uB274");
		lblNewLabel_2.setBounds(67, 10, 57, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\uC8FC\uBB38");
		lblNewLabel_3.setBounds(67, 205, 57, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel label = new JLabel("\uC74C\uC2DD:");
		label.setBounds(631, 42, 69, 15);
		contentPane.add(label);
		
		JButton btnNewButton_1 = new JButton("\uC8FC\uBB38\uD558\uAE30");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				++tab;
				JOptionPane.showMessageDialog(null, "�ֹ��� �Ϸ�Ǿ����ϴ�.");
				
				try{
			         Connection con = (Connection) dbc.dbcon();
			         String sql = "select*from older where orderlist =\'"+tab+"\'";
			         Statement st= (Statement) con.createStatement();
			         ResultSet Rs = st.executeQuery(sql);
			         table_1.setModel(DbUtils.resultSetToTableModel(Rs));
			      }catch(Exception w){
			         w.printStackTrace();
			         
			      } 
				
				
				
				
				
			}
		});
		btnNewButton_1.setBounds(731, 293, 97, 53);
		contentPane.add(btnNewButton_1);
		
		JLabel label_1 = new JLabel("\uAC00\uACA9:");
		label_1.setBounds(631, 78, 69, 15);
		contentPane.add(label_1);
		
		tf_food = new JTextField();
		tf_food.setEditable(false);
		tf_food.setText("");
		tf_food.setColumns(10);
		tf_food.setBounds(712, 42, 116, 21);
		contentPane.add(tf_food);
		
		tf_price = new JTextField();
		tf_price.setEditable(false);
		tf_price.setText("");
		tf_price.setColumns(10);
		tf_price.setBounds(712, 75, 116, 21);
		contentPane.add(tf_price);
		
		tf_num = new JTextField();
		tf_num.setEnabled(false);
		tf_num.setEditable(false);
		tf_num.setBounds(123, 197, 20, 23);
		contentPane.add(tf_num);
		tf_num.setColumns(10);
	}
}
