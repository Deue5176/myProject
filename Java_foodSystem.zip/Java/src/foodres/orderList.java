package foodres;



import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.PreparedStatement;

import foodres.Main;
import net.proteanit.sql.DbUtils;
import foodres.dbc;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;





import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import foodres.Main;
import foodres.dbc;
import foodres.DBConnectionMgr;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTabbedPane;

 


@SuppressWarnings({ "unused", "serial" })
public class orderList extends JFrame {

	private JPanel contentPane;
	
    static String tn = "food1";
    private JTable table_1;
    static int num = 1;
    static int tab = 0;
    private JTextField tf_num;
  

		

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		orderList frame = new orderList();
		frame.setVisible(true);
	}

	/**
	 * Create the frame.
	 */
	public orderList() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 510, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		try{
	         Connection con = (Connection) dbc.dbcon();
	         String sql = "select*from food1";
	         Statement st= (Statement) con.createStatement();
	         ResultSet Rs = st.executeQuery(sql);

	      }catch(Exception w){
	         w.printStackTrace();
	         
	      }
		
		JButton btnNewButton_2 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.showadmin();
				dispose();
			}
		});
		btnNewButton_2.setBounds(385, 393, 97, 23);
		contentPane.add(btnNewButton_2);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(12, 35, 452, 327);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row = table_1.getSelectedRow();
				if(row>=0){
				

				String name = table_1.getValueAt(table_1.getSelectedRow(), 0).toString();
				
				
				tf_num.setText(name);

	
				
				}
				else
				{
					return;
				
			
			
			
		}
			}
		});
		try{
	         Connection con = (Connection) dbc.dbcon();
	         String sql = "select*from older";
	         Statement st= (Statement) con.createStatement();
	         ResultSet Rs = st.executeQuery(sql);
	         table_1.setModel(DbUtils.resultSetToTableModel(Rs));
	      }catch(Exception w){
	         w.printStackTrace();
	         
	      } 
		
		scrollPane_1.setViewportView(table_1);
		
		JLabel lblNewLabel_3 = new JLabel("\uC8FC\uBB38");
		lblNewLabel_3.setBounds(12, 10, 57, 15);
		contentPane.add(lblNewLabel_3);
		
		tf_num = new JTextField();
		tf_num.setEnabled(false);
		tf_num.setEditable(false);
		tf_num.setBounds(42, 6, 20, 23);
		contentPane.add(tf_num);
		tf_num.setColumns(10);
	}
}
