package foodres;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;



public class Main {
	
	
	public class dbCon {

	}


	static String driver, url;
	static Connection conn;
	static Statement stmt;
	static ResultSet rs;
	static String tmpstr;
	
	public static void main(String[] args){
		home home = new home();
		home.setVisible(true);
		
	}
	public static void showadmin(){
		admin frame = new admin();
		frame.setVisible(true);
	}
	
	public static void closeHome(){
		home home1 = new home();
		home1.setVisible(false);
	}
	

	public static void showaloign(){
		login login1 = new login();
		login1.setVisible(true);
	}
	
	public static void showorder(){
		order order = new order();
		order.setVisible(true);
	}
	
	public static void showhome(){
		home home = new home();
		home.setVisible(true);
	}
	
	public static void showfood(){
		foodList foodList = new foodList();
		foodList.setVisible(true);
	}
	
	public static void showorist(){
		orderList orderList = new orderList();
		orderList.setVisible(true);
	}

	
	
	public static void dbDis(){
		try {
			if (conn != null)
				conn.close();
			if (stmt != null)
				stmt.close();
			System.out.println("�����ͺ��̽� ���� ����!");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	

public static void dbCon() {
	driver = "sun.jdbc.odbc.JdbcOdbcDriver";
	try{
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("����̹� �˻� ����!");        
	}catch(ClassNotFoundException e){
		System.err.println("error = " + e);
	}
    
	
    url = "jdbc:odbc:restaurant";
    conn = null;
    stmt = null;
    rs = null;
    String url = "jdbc:mysql://localhost/restaurant";
    String sql = "Select * From food1";
	try {
     
        conn = DriverManager.getConnection(url,"root","apmsetup");

        stmt = conn.createStatement( );

        rs = stmt.executeQuery(sql);
        
        System.out.println("�����ͺ��̽� ���� ����!");            
     
    }
    catch(Exception e) {
        System.out.println("�����ͺ��̽� ���� ����!");
    }
}






}
