package foodres;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.PreparedStatement;

import foodres.Main;
import net.proteanit.sql.DbUtils;
import foodres.dbc;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import foodres.Main;
import foodres.dbc;
import foodres.DBConnectionMgr;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

@SuppressWarnings({ "unused", "serial" })
public class foodList extends JFrame {

	private JPanel contentPane;
	private JTextField tf_code;
	private JTextField tf_name;
	private JTextField tf_price;
	private JTable table;

	static String tn = "food1";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		foodList frame = new foodList();
		frame.setVisible(true);
	}

	/**
	 * Create the frame.
	 */
	public foodList() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 547, 569);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);

		JScrollPane scrollPane = new JScrollPane();

		scrollPane.setBounds(140, 10, 379, 297);
		contentPane.add(scrollPane);

		table = new JTable();
		try {
			Connection con = (Connection) dbc.dbcon();
			String sql = "select*from food1";
			Statement st = (Statement) con.createStatement();
			ResultSet Rs = st.executeQuery(sql);
			table.setModel(DbUtils.resultSetToTableModel(Rs));
			tf_code.setText("");
			tf_name.setText("");
			tf_price.setText("");
		} catch (Exception w) {
			w.printStackTrace();

		}

		scrollPane.setViewportView(table);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				int row = table.getSelectedRow();
				if (row >= 0) {

					String num = table.getValueAt(table.getSelectedRow(), 0).toString();
					String name = table.getValueAt(table.getSelectedRow(), 1).toString();
					String date = table.getValueAt(table.getSelectedRow(), 2).toString();
					tf_code.setText(num);
					tf_name.setText(name);
					tf_price.setText(date);

				} else {
					return;

				}
			}
		});

		JButton btnNewButton = new JButton("\uAE40\uBC25");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tn = null;
				tn = "food1";

				try {
					Connection con = (Connection) dbc.dbcon();
					String sql = "select*from food1";
					Statement st = (Statement) con.createStatement();
					ResultSet Rs = st.executeQuery(sql);
					table.setModel(DbUtils.resultSetToTableModel(Rs));
					tf_code.setText("");
					tf_name.setText("");
					tf_price.setText("");
				} catch (Exception w) {
					w.printStackTrace();

				}

			}
		});
		btnNewButton.setBounds(12, 13, 97, 23);
		contentPane.add(btnNewButton);

		tf_code = new JTextField();
		tf_code.setBounds(140, 368, 116, 21);
		contentPane.add(tf_code);
		tf_code.setColumns(10);

		JLabel lblNewLabel = new JLabel("code :");
		lblNewLabel.setBounds(71, 371, 57, 15);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("name :");
		lblNewLabel_1.setBounds(71, 396, 57, 15);
		contentPane.add(lblNewLabel_1);

		tf_name = new JTextField();
		tf_name.setColumns(10);
		tf_name.setBounds(140, 393, 116, 21);
		contentPane.add(tf_name);

		tf_price = new JTextField();
		tf_price.setColumns(10);
		tf_price.setBounds(140, 422, 116, 21);
		contentPane.add(tf_price);

		JLabel lblPrice = new JLabel("price :");
		lblPrice.setBounds(71, 425, 57, 15);
		contentPane.add(lblPrice);

		JButton btnNewButton_1 = new JButton("\uC218 \uC815");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try {

					String sql = "update " + tn + " set id = '" + tf_code.getText() + "',name='" + tf_name.getText()
							+ "',price = '" + "" + tf_price.getText() + "' where id='" + tf_code.getText() + "'";
					Connection con = (Connection) dbc.dbcon();

					Statement s = (Statement) con.prepareStatement(sql);

					JOptionPane.showMessageDialog(null, "������ ���̽� ���� ����");
					tf_code.setText("");
					tf_name.setText("");
					tf_price.setText("");
					s.execute(sql);
					String sql1 = "select*from " + tn;
					Statement st = (Statement) con.createStatement();
					ResultSet Rs = st.executeQuery(sql1);
					table.setModel(DbUtils.resultSetToTableModel(Rs));

				} catch (Exception ex) {
					ex.printStackTrace();
					JOptionPane.showMessageDialog(null, "������ ���̽� ���� ����");
				}
			}
		});
		btnNewButton_1.setBounds(422, 367, 97, 23);
		contentPane.add(btnNewButton_1);

		JButton button = new JButton("\uC0BD \uC785");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					Connection con = (Connection) dbc.dbcon();

					PreparedStatement pstmtAdd = (PreparedStatement) con
							.prepareStatement("insert into " + tn + " values(?,?,?)");

					pstmtAdd.setString(1, tf_code.getText());
					pstmtAdd.setString(2, tf_name.getText());
					pstmtAdd.setString(3, tf_price.getText());

					pstmtAdd.executeUpdate();
					String sql = "select*from " + tn;
					Statement st = (Statement) con.createStatement();
					ResultSet Rs = st.executeQuery(sql);
					table.setModel(DbUtils.resultSetToTableModel(Rs));
					tf_code.setText("");
					tf_name.setText("");
					tf_price.setText("");

				} catch (Exception w) {
					w.printStackTrace();

				}

			}
		});

		button.setBounds(422, 392, 97, 23);
		contentPane.add(button);

		JButton button_1 = new JButton("\uC0AD \uC81C");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					String sql = "delete from " + tn + " where id= '" + tf_code.getText() + "'";
					Connection con = (Connection) dbc.dbcon();
					Statement s = (Statement) con.prepareStatement(sql);

					JOptionPane.showMessageDialog(null, "������ ���̽� ���� ����");
					tf_code.setText("");
					tf_name.setText("");
					tf_price.setText("");
					s.execute(sql);
					String sql1 = "select*from " + tn;
					Statement st = (Statement) con.createStatement();
					ResultSet Rs = st.executeQuery(sql1);
					table.setModel(DbUtils.resultSetToTableModel(Rs));

				} catch (Exception ex) {
					ex.printStackTrace();
					JOptionPane.showMessageDialog(null, "������ ���̽� ���� ����");
				}

			}
		});
		button_1.setBounds(422, 421, 97, 23);
		contentPane.add(button_1);

		JButton btnNewButton_2 = new JButton("\uB4A4\uB85C\uAC00\uAE30");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.showadmin();
				dispose();
			}
		});
		btnNewButton_2.setBounds(12, 497, 97, 23);
		contentPane.add(btnNewButton_2);

		JButton button_2 = new JButton("\uB77C \uBA74");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tn = null;
				tn = "food2";

				try {
					Connection con = (Connection) dbc.dbcon();
					String sql = "select*from food2";
					Statement st = (Statement) con.createStatement();
					ResultSet Rs = st.executeQuery(sql);
					table.setModel(DbUtils.resultSetToTableModel(Rs));
					tf_code.setText("");
					tf_name.setText("");
					tf_price.setText("");
				} catch (Exception w) {
					w.printStackTrace();

				}

			}
		});
		button_2.setBounds(12, 46, 97, 23);
		contentPane.add(button_2);

		JButton button_3 = new JButton("\uB5A1\uBCF6\uC774");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tn = null;
				tn = "food3";

				try {
					Connection con = (Connection) dbc.dbcon();
					String sql = "select*from food3";
					Statement st = (Statement) con.createStatement();
					ResultSet Rs = st.executeQuery(sql);
					table.setModel(DbUtils.resultSetToTableModel(Rs));
					tf_code.setText("");
					tf_name.setText("");
					tf_price.setText("");
				} catch (Exception w) {
					w.printStackTrace();

				}

			}
		});
		button_3.setBounds(12, 79, 97, 23);
		contentPane.add(button_3);
	}
}
