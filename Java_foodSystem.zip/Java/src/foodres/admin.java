package foodres;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings({ "unused", "serial" })
public class admin extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin frame = new admin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public admin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 318, 180);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("\uBAA8\uB4E0 \uC8FC\uBB38 \uC870\uD68C");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.showorist();
				dispose();
			}
		});
		btnNewButton.setBackground(Color.CYAN);
		btnNewButton.setBounds(12, 30, 270, 23);
		contentPane.add(btnNewButton);
		
		JButton button_1 = new JButton("\uB85C\uADF8\uC544\uC6C3");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.showhome();
				dispose();
			}
		});
		button_1.setBackground(Color.CYAN);
		button_1.setBounds(12, 96, 270, 23);
		contentPane.add(button_1);
		
		JButton btnNewButton_1 = new JButton("\uC74C\uC2DD\uAD00\uB9AC");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Main.showfood();
				dispose();

			}
		});
		btnNewButton_1.setBounds(12, 63, 270, 23);
		contentPane.add(btnNewButton_1);
	}
}
